window.onload = draw;
function draw() {
  let myCanvas = document.getElementById("my-canvas");
  if (myCanvas.getContext) {
    let ctx = myCanvas.getContext("2d");
    casovnik(ctx);
  } else {
    alert("Canvas is not supported.");
  }
}
let angleSekunda = 0;
let angleMinut = 0;
let angleSat = 0;

function casovnik(ctx) {
  // sekunda**********************************
  ctx.save();
  let img = new Image();
  img.addEventListener("load", function () {
    ctx.clearRect(0, 0, 400, 300);
    ctx.drawImage(img, 70, 20, 260, 260);
  });

  img.src = "casovnik.png";

  ctx.translate(200, 150);
  ctx.rotate((6 / 3600) * angleSekunda);
  ctx.translate(-200, -150);
  ctx.beginPath();
  ctx.moveTo(200, 150);
  ctx.lineTo(200, 30);
  ctx.closePath();
  ctx.stroke();
  ctx.restore();

  angleSekunda++;

  // sat**********************************

  ctx.save();
  ctx.translate(200, 150);
  ctx.rotate((0.16 / 360000) * angleSat);
  ctx.translate(-200, -150);
  ctx.beginPath();
  ctx.moveTo(200, 150);
  ctx.lineTo(250, 200);
  ctx.stroke();
  ctx.restore();
  angleSat++;
  // minut***************************************
  ctx.save();
  ctx.translate(200, 150);
  ctx.rotate((1 / 36000) * angleMinut);
  ctx.translate(-200, -150);
  ctx.beginPath();
  ctx.moveTo(200, 150);
  ctx.lineTo(150, 50);
  ctx.closePath();
  ctx.stroke();
  ctx.restore();

  angleMinut++;
  requestId = requestAnimationFrame(function () {
    casovnik(ctx);
  });
}
